import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.patches as patches


def draw_relation_as_venn_diagram(A, B, R, A_label='A', B_label='B'):

    A = sorted(list(A))
    B = sorted(list(B))

    # Create a directed bipartite graph from the relation R
    G = nx.DiGraph()
    G.add_nodes_from([f"A_{a}" for a in A], bipartite=0)
    G.add_nodes_from([f"B_{b}" for b in B], bipartite=1)

    G.add_edges_from( (f"A_{a}", f"B_{b}") for (a, b) in R )

    pos = {}
    pos.update( (f"A_{n}", (1, i)) for i, n in enumerate(A) ) # put nodes from A at x=1
    pos.update( (f"B_{n}", (3, i)) for i, n in enumerate(B) ) # put nodes from B at x=2

    labels = {n:n.split("_")[1] for n in G.nodes()}

    fig, ax = plt.subplots(figsize=(4, 3))

    # Draw rectangles for A and B sets
    rect_height = max(len(A), len(B)) - 0.5
    ax.add_patch(patches.Rectangle((0.5, -0.5), 1, len(A),
                 linewidth=1, edgecolor='black', facecolor='lightgray', alpha=0.3))
    ax.add_patch(patches.Rectangle((2.5, -0.5), 1, len(B),
                 linewidth=1, edgecolor='black', facecolor='lightgray', alpha=0.3))

    # Add labels for A and B above rectangles
    ax.text(1, rect_height + 0.1, A_label, ha='center', va='bottom', fontsize=12, fontweight='bold')
    ax.text(3, rect_height + 0.1, B_label, ha='center', va='bottom', fontsize=12, fontweight='bold')

    # Draw graph
    nx.draw(G, pos=pos, labels=labels, with_labels=True, arrows=True, node_color='lightblue')
    plt.show()



def draw_relation_on_set_as_digraph(A, R, layout='circular'):
    import networkx as nx
    import matplotlib.pyplot as plt

    # Create directed graph
    G = nx.DiGraph()
    G.add_nodes_from(A)
    G.add_edges_from(R)

    # Set layout
    if layout=='spring':
        pos = nx.spring_layout(G)
    else:
        pos = nx.circular_layout(G)


    fig, ax = plt.subplots(figsize=(4, 4))

    # Draw nodes and directed edges
    nx.draw(
        G,
        pos=pos,
        with_labels=True,
        arrows=True,
        node_color='lightblue',
        font_weight='bold',
        ax=ax
    )

    # Draw self-loops (if any), slightly offset for clarity
    loop_edges = [(u, v) for u, v in R if u == v]
    if loop_edges:
        nx.draw_networkx_edges(
            G,
            pos,
            edgelist=loop_edges,
            connectionstyle='arc3,rad=0.3',
            arrows=True
        )
    ax.set_axis_off()
    plt.tight_layout()
    plt.show()